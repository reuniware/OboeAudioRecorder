var searchData=
[
  ['usage',['Usage',['../namespaceoboe.html#a104ee8396c173fefac429759ea3c21a0',1,'oboe']]]
];
