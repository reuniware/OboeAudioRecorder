var indexSectionsWithContent =
{
  0: "abcdefgiklmnoprstuvw",
  1: "adflrsv",
  2: "o",
  3: "acefgiloprstuvw",
  4: "cfkmnpst",
  5: "acdiprsu",
  6: "abcefgilmnopsuv",
  7: "ad"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues",
  7: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Enumerator",
  7: "Pages"
};

