var searchData=
[
  ['samplerate',['SampleRate',['../classoboe_1_1_default_stream_values.html#a46a5d9a653f2153f618cadcab764e1b1',1,'oboe::DefaultStreamValues']]]
];
