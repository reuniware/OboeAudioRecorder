var searchData=
[
  ['audioapi',['AudioApi',['../namespaceoboe.html#a92972414867c81d5974cb2ed7abefbf6',1,'oboe']]],
  ['audioformat',['AudioFormat',['../namespaceoboe.html#a92afc593e856571aacbfd02e57075df6',1,'oboe']]]
];
