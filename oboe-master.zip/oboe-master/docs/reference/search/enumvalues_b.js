var searchData=
[
  ['powersaving',['PowerSaving',['../namespaceoboe.html#a1068781f3920654b1bfd7ed136468184abbad080463ed11f9d77797c04aa1e5b1',1,'oboe']]]
];
