var searchData=
[
  ['pause',['pause',['../classoboe_1_1_audio_stream.html#a04f29836748a8e5842aef2be200022ad',1,'oboe::AudioStream']]]
];
