var searchData=
[
  ['updateframesread',['updateFramesRead',['../classoboe_1_1_audio_stream.html#a462358ddab709c79d1a7968d6d55b727',1,'oboe::AudioStream']]],
  ['updateframeswritten',['updateFramesWritten',['../classoboe_1_1_audio_stream.html#a64ad978c5f70ced17ef5a96605496515',1,'oboe::AudioStream']]],
  ['usesaaudio',['usesAAudio',['../classoboe_1_1_audio_stream.html#a15cdaaaa4c1e8da322d6da33334c8147',1,'oboe::AudioStream']]]
];
