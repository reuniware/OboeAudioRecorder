var searchData=
[
  ['tune',['tune',['../classoboe_1_1_latency_tuner.html#ad2be756965e6a9af3114008eda892174',1,'oboe::LatencyTuner']]]
];
