var searchData=
[
  ['samplerateconversionquality',['SampleRateConversionQuality',['../namespaceoboe.html#a82f3720eba7654aceb7282be36f9ff1d',1,'oboe']]],
  ['sessionid',['SessionId',['../namespaceoboe.html#a5752250c10e96179e3618d7f72937eaf',1,'oboe']]],
  ['sharingmode',['SharingMode',['../namespaceoboe.html#a8330247b25429953a08354f41834d520',1,'oboe']]],
  ['streamstate',['StreamState',['../namespaceoboe.html#a89fa2ce046723764618c29db737917f6',1,'oboe']]]
];
