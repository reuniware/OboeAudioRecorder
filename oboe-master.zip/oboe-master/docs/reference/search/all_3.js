var searchData=
[
  ['datacallbackresult',['DataCallbackResult',['../namespaceoboe.html#af85fc9910a287df6c5df0ed396bb75cd',1,'oboe']]],
  ['defaultstreamvalues',['DefaultStreamValues',['../classoboe_1_1_default_stream_values.html',1,'oboe']]],
  ['deprecated_20list',['Deprecated List',['../deprecated.html',1,'']]],
  ['direction',['Direction',['../namespaceoboe.html#af2147500089212955498a08ef2edb5ae',1,'oboe']]]
];
