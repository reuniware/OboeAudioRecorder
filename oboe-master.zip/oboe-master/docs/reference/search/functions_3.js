var searchData=
[
  ['firedatacallback',['fireDataCallback',['../classoboe_1_1_audio_stream.html#ab7a8cfe5d6039386bc5850fd5ee9bd62',1,'oboe::AudioStream']]],
  ['flush',['flush',['../classoboe_1_1_audio_stream.html#a32c25c0333eab3d65ce02275ad4acb3d',1,'oboe::AudioStream']]]
];
