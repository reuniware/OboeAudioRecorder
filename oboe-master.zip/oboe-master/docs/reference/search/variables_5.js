var searchData=
[
  ['patch',['Patch',['../structoboe_1_1_version.html#a690110f2b3e887892da8f29ab5c057b2',1,'oboe::Version']]]
];
