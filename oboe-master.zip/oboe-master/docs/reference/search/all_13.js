var searchData=
[
  ['waitforavailableframes',['waitForAvailableFrames',['../classoboe_1_1_audio_stream.html#afddb0962863ccf9ec6672a042fe15941',1,'oboe::AudioStream']]],
  ['waitforstatechange',['waitForStateChange',['../classoboe_1_1_audio_stream.html#a0c865a5501f369d959c39d8ab8b46a07',1,'oboe::AudioStream']]],
  ['waitforstatetransition',['waitForStateTransition',['../classoboe_1_1_audio_stream.html#a8adbacd6a55a94a532916ab037fba1d6',1,'oboe::AudioStream']]],
  ['waserrorcallbackcalled',['wasErrorCallbackCalled',['../classoboe_1_1_audio_stream.html#aa48da7bf28026b7cccee73e6b054af28',1,'oboe::AudioStream']]],
  ['willuseaaudio',['willUseAAudio',['../classoboe_1_1_audio_stream_builder.html#aa07ea100fcb107d9f7913f206c2214f4',1,'oboe::AudioStreamBuilder']]],
  ['write',['write',['../classoboe_1_1_audio_stream.html#a3612c05ed6b01a213dde67d913c07e11',1,'oboe::AudioStream']]]
];
