var searchData=
[
  ['opensles',['OpenSLES',['../namespaceoboe.html#a92972414867c81d5974cb2ed7abefbf6a24e758ea9c1e842ef71cc8ff8b63fa9b',1,'oboe']]],
  ['output',['Output',['../namespaceoboe.html#af2147500089212955498a08ef2edb5aea29c2c02a361c9d7028472e5d92cd4a54',1,'oboe']]]
];
