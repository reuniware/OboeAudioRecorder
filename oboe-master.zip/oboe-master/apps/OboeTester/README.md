# Oboe Tester

OboeTester is an app that can be used to test many of the features of Oboe, AAudio and OpenSL ES.
It can also be used to measure device latency and glitches.

# [OboeTester Documentation](docs)
