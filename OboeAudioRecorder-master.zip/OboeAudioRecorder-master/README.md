# OboeAudioRecorder

I created this project some days ago, in order to get skills in Android JNI/NDK/C++ and Google Oboe library.

On 3rd of July 2020, it records audio to a buffer in memory.

On 5th of July 2020, it records the audio to a .wav file on the Android device (in the "Recorders" folder).
You can start the recording, leave the app (let it in the background) and it will keep on recording the mic input, even if the Android device is in idle mode. Then you get back to the app, stop the recording, and the wav file is available in the "Recorders" directory.

Feel free to contact me at : 
investdatasystems@yahoo.com
kotlinisland@protonmail.com

And to check one of my websites :
https://ntic974.blogspot.com
